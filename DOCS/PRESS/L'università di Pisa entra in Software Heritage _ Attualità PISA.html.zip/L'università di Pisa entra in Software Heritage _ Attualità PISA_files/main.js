$(document).ready(function() {
	
	$('.fotogallery').flexslider({
		slideshow: false,
		animation: "slide",
		animationLoop: false,
		controlNav: false,
		itemWidth:200
	});
	
	$('.videogallery').flexslider({
		slideshow: false,
		animation: "slide",
		animationLoop: false,
		controlNav: false,
		itemWidth: 200
	});
	
	$('.fotogallery').magnificPopup({
		type:'image',
		delegate: 'a.foto',
		gallery: {
			enabled: true
		},
		image: { 
		  	titleSrc: function (){
		  				var autore = $('.fotogallery.flexslider ').attr('data-photographer');
		  				var dida = this.currItem.el.attr('title');
			  			if(autore){
			  				return dida + '<small class="photographer-sign">Foto di: ' + autore +'</small>';
			  			}else{
			  				return dida;
			  			}
		  			}
	   		}			
	});
	
	// $('.videogallery').magnificPopup({
	// 	type:'iframe',
	// 	delegate: 'a.video',
	// 	gallery: {
	//     	enabled: true
	// 	}
	// });
	
	if($('#adv_click a').length){
		$('#adv_click a').on('click', function() {
			var href = $(this).attr('href');
			ga('send', 'event', { eventCategory: 'skin', eventAction: 'click', eventLabel: 'Click sulla skin ('+href+')'});
		});
	}

	$("a.fancybox-button").fancybox();
	
	$('.ImageLink.ImageLinkVideo').magnificPopup({
		type:'iframe'
	});

	
    var timeout;
	$("#filter").keyup(function(){

	    var filter = $(this).val(), count = 0;
	    var href = '';
	    clearTimeout(timeout);
	    $(".person").each(function(){

	        // If the list item does not contain the text phrase fade it out
	        if ($(this).find('h2 a').text().search(new RegExp(filter, "i")) < 0) {
	            $(this).fadeOut();
	        } else {
	            href = $(this).find('h2 a').attr('href');
	            $(this).show();
	            count++;
	        }
	    });

	    if(count==1) {
	    	timeout = setTimeout(function() {
	    		if(href != '')
	    			window.location.href = href;
	    	}, 2000);
	    }

	    // Update the count
	    var numberItems = count;
	});


	$('.marquee-with-options').marquee({
   	speed: 15000,
   	gap: 0,
   	delayBeforeStart: 0,
   	direction: 'left',
   	duplicated: true,
   	pauseOnHover: true
   });

	$('body').on('click', '.submitButton', function(e) {
		e.preventDefault();
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		let form = $(this).parent().parent().parent();
		let action = form.attr('action');

		let error = false;
		if(document.forms.signup_form.first_name.value == '') {
			document.forms.signup_form.first_name.style.border = '1px solid red';
			error = true;
		}
		if(document.forms.signup_form.last_name.value == '') {
			document.forms.signup_form.last_name.style.border = '1px solid red';
			error = true;
		}
		if(document.forms.signup_form.email_1.value == '' || re.test(document.forms.signup_form.email_1 == false)) {
			document.forms.signup_form.email_1.style.border = '1px solid red';
			error = true;
		}

		if(document.forms.signup_form.privacy.checked == false) {
			document.forms.signup_form.privacy.parentNode.style.borderBottom = '1px solid red';
			error = true;
		}

		if(document.forms.signup_form.newsletter.checked == false) {
			document.forms.signup_form.newsletter.parentNode.style.borderBottom = '1px solid red';
			error = true;
		}

		if(error === true) {
			$('#response-alert').addClass('alert-danger').show();
			$('#response-alert').html('<strong>ATTENZIONE</strong>: non sono stati compilati correttamenti tutti i dati del modulo. Ricontrolla e riprova.');
			return;
		}

		$.ajax({
			method: "POST",
			url: action,
			data: form.serializeArray(),
			success: function(response) {
				if(response.success == true) {
					writeCookie('subscribed', true, 365*2);
					$('#response-alert').removeClass('alert-danger').addClass('alert-success').show();
					$('#response-alert').text('Grazie per esserti iscritto. La pagina si aggiornerà a breve');
					setTimeout(function() {
						window.location.reload();
					}, 2000);
				}else{
					$('#response-alert').addClass('alert-danger').show();
					$('#response-alert').html('<strong>ATTENZIONE</strong>: ' + response.error);
				}
			}
		});
	});
	
	var hash_open = false;
	var opened = false;
	var offset = 350;
	var minTime = 2500;
	if(window.location.hash == '#open_subscribe') {
		showModal();
		hash_open = true;
		opened = true;
	}

	$(window).scroll(function(e) {
      // Se non ho settato il subscribed; se non ho il parametro subscribe; se non ho già  visto il popup per questa sessione; se non sono loggato e non ho nessun fragment
      if ((!getCookie('subscribed') && getParameterByName('subscribe') != 'yes' && !getCookie('onscroll-sub')) || (hash_open && !opened)) {
        var position = jQuery(window).scrollTop();
        if (position > offset) {
          if(opened == false){
            opened = true;
            setTimeout(function() {
            	writeCookie('onscroll-sub', true, 3);
            	showModal();
            }, minTime);
            // ga('send', 'event', { eventCategory: 'layered-popup', eventAction: 'show'});
          }
        }
      }
    });

	
});

// scrivo cookie
function writeCookie(key, value, days) {
  if (days) {
    var date = new Date();
    date.setTime(date.getTime()+(days*24*60*60*1000));
    var expires = "; expires="+date.toGMTString();
  } else var expires = "";
  document.cookie = key+"="+value+expires+"; path=/; domain="+window.location.hostname.replace('www', '')+"";
}

// recupero cookie
function getCookie(name) {
  var value = "; " + document.cookie;
  var parts = value.split("; " + name + "=");
  if (parts.length == 2) return parts.pop().split(";").shift();
}

// recupero parametri query_string
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function showModal() {
	let city = $('.datebox span strong').text().toLowerCase();
	var form = '<div class="aler alert-danger" id="response-alert" style="display: none;padding: 10px;margin-bottom: 5px;"></div>'
	// form += '<h3 style="margin-top: 0;">Resta sempre aggiornato su quel che accade a '+ (city.charAt(0).toUpperCase() + city.slice(1)) +'</h3>';
	form += '<h3 style="margin-top: 0;">Resta sempre aggiornato su quel che accade sul territorio</h3>';
	form += '<p style="font-size: 15px;">Non perderti le più importanti notizie della tua città.<br/>Per te news in anteprima e informazioni di pubblica utilità, meteo, traffico, scuole, eventi e molto altro. <br/><br/>Quinews.net: l\'informazione vicino a te</p><div class="clear"></div>';
	form += '<form action="/user/signup" name="signup_form" class="row" method="POST">';
	form += '	<div class="col-md-8 col-md-push-2">';
	form += '		<div class="col-md-12">';
	form += '			<br/>';
	form += '			<label>Nome</label>';
	form += '			<input class="form-control" type="text" name="first_name" placeholder="Nome" />';
	form += '			<br />';
	form += '		</div>';
	form += '		<div class="col-md-12">';
	form += '			<label>Cognome</label>';
	form += '			<input class="form-control" type="text" name="last_name" placeholder="Cognome" />';
	form += '			<br />';
	form += '		</div>';
	form += '		<div class="col-md-12">';
	form += '			<label>Email</label>';
	form += '			<input class="form-control" type="email" name="email_1" placeholder="Email" />';
	form += '		</div>';
	form += '		<div class="col-md-12">';
	form += '			<br/>';
	form += '			<label><input type="checkbox" name="privacy" /> Accetto i termini e condizioni della privacy</label>';
	form += '			<label><input type="checkbox" name="newsletter" /> Accosento alla ricezione di email utili e informative</label>';
	form += '			<br />';
	form += '			<a href="#" class="btn btn-block btn-primary submitButton">Iscriviti ora</a>';
	form += '		</div>';
	form += '	</div>';
	form += '</form>';

	$.popup('alert', {title: 'Resta sempre aggiornato, iscriviti a Quinews.net', body: form});
}

function tweetlink(tweet) {
        return tweet.replace(/\b(((https*\:\/\/)|www\.)[^\"\']+?)(([!?,.\)]+)?(\s|$))/g, function(link, m1, m2, m3, m4) {
          var http = m2.match(/w/) ? 'http://' : '';
          return '<a class="twtr-hyperlink" target="_blank" href="' + http + m1 + '">' + ((m1.length > 25) ? m1.substr(0, 24) + '...' : m1) + '</a>' + m4;
        });
      }

function tweetat(tweet) {
        return tweet.replace(/\B[@＠]([a-zA-Z0-9_]{1,20})/g, function(m, username) {
          return '<a target="_blank" class="twtr-atreply" href="http://twitter.com/' + username + '">@' + username + '</a>';
        });
      }

function formattweet(tweet) {
        return this.at(this.link(tweet));
      }

$.popup = function(type,message,callback,defaultValue, id, html) {
	var type = type || 'alert';
	var message = message || '';
	var callback = callback || function(){};
	var defaultValue = defaultValue || '';
	var id_popup = '';

	var confirm_id_popup = '';
	id_popup = 'message-popup-' + parseInt(Math.random() * 100000);
	confirm_id_popup = 'confirm-button-' + parseInt(Math.random() * 100000);
  
	build_modal(message, confirm_id_popup, id_popup);
}
  
function build_modal(message, confirm_id_popup, id_popup){
	var title = (typeof(message['title']) === 'undefined') ? 'ATTENZIONE!' : message['title'];
	var close = (typeof(message['close']) === 'undefined') ? '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>' : message['close'];
	// var id_popup = parseInt(Math.random() * 100000);
	var div_dialog = $('<div class="modal-dialog">');
	var div_content = $('<div class="modal-content">');
	var div_header = $('<div class="modal-header">'+close+'<h3 class="modal-title" id="modalSharingLabel">'+title+'</h3></div>');
	var div_footer = $('<div class="modal-footer">');

	var div_message = $('<div class="modal-body">' + message['body'] + '</div>');

	if(typeof(message['footer']) === 'undefined'){
	  div_footer.append('<button type="button" id="' + confirm_id_popup + '" data-dismiss="modal" class="btn btn-default">Non adesso</button>');
	}else{
	  div_footer.append(message['footer']);
	}

	$('<div id="' + id_popup + '" class="modal" tabindex="-1" data-backdrop="static">').appendTo('body')
	.append(div_dialog);

	div_dialog.append(div_content);
	div_content.append(div_header).append(div_message).append(div_footer);

	// $('#'+id_popup).click(function(){ 
	//     if (type == 'prompt') {
	//       callback($('#prompt-input-' + id_popup).val());
	//     } else {
	//       callback();
	//     }
	//   });

	$('#'+id_popup).modal();
	$('#'+id_popup).removeClass('hide');
}


$.alert = function (message,callback) {
  $.popup('alert', message, callback);
}
