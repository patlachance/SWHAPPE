/*

########### ISTRUZIONI PER CONFIGURAZIONE fb-popup ###################

includere il file specificando 4 parametri

<script src="/fb-popup/fb-popup.js" data-sec="20" data-how-many-days="7" data-site-prefix="valdera" data-fb-account="QuiValdera.it" id="fb-popup"  ></script>

Secondi dopo i quali viene mostrato il popup una volta atterrati sulla pagina.
sec = numero

Prefisso identificativo del sito
site-prefix = valdera - quinewsvaldera

Numero di giorni dopo i quali far rivisualizzare il popup
how-many-days = 7 giorni

Aggiungere nel footer della template generale il seguente codice (solo con fancybox)
<a href="splashpopup.html" style="display:none;" id="popupsplash">newsletter</a> 


controllare se c'è necessità di aggiungere questa rewrite nel file common del sito

################################################################################

*/
 
$(document).ready(function(){

    var oneday = 60*60*24;
    var fifteenDays = 1000*60*60*24*15;
    var lastvisitday = 0;
    var sec = $('#fb-popup').attr('data-sec')*1000;
    var today = $('#fb-popup').attr('data-timevisit');
    var facebook = $('#fb-popup').attr('data-fb-account');
    var prefix = $('#fb-popup').attr('data-site-prefix');
    var howmanydays = $('#fb-popup').attr('data-how-many-days');
    var expires = new Date((new Date()).valueOf() + fifteenDays);
    var now = parseInt(new Date().getTime()/1000);
    var nextshow = oneday*parseInt(howmanydays);

    if (document.cookie.indexOf(prefix+'_visited=true') == -1) {
        document.cookie = prefix+'_visited=true;path=/;expires=' + expires.toUTCString();
    }else if(document.cookie.indexOf(prefix+'_timevisit') == -1){
        lastvisitday = 0;                
    }else{

        timevisit = parseInt(getCookie('timevisit'));
        lastvisitday = now - timevisit;
        if(lastvisitday>=nextshow){
            lastvisitday = 0;
        }

    }

    var mobile = 0;

    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {

        mobile = 1;

    }


    if(lastvisitday==0 && mobile==0){
        // console.log('prima del fancybox');
        setTimeout(function(){
             //SCOMMENTARE PER RIATTIVARE IL POPUP
            // mostraSplashPopup(facebook,prefix);
            document.cookie = prefix+'_timevisit='+ now +';path=/;expires=' + expires.toUTCString();
        }
        ,sec);        
        // console.log('dopo del fancybox');
    }
   

});

function show_and_set(prefix, now, expiration){
     //SCOMMENTARE PER RIATTIVARE IL POPUP
    // mostraSplashPopup();
    document.cookie = prefix+'_last_shown='+ now +';path=/;expires=' + expiration.toUTCString();
}


function getCookie(c_name){
    var c_value = document.cookie;
    var c_start = c_value.indexOf(" " + c_name + "=");

    if (c_start == -1){
        c_start = c_value.indexOf(c_name + "=");
    }

    if (c_start == -1){
        c_value = null;
    }else{
        c_start = c_value.indexOf("=", c_start) + 1;
        var c_end = c_value.indexOf(";", c_start);
        if (c_end == -1){
            c_end = c_value.length;
        }
        c_value = unescape(c_value.substring(c_start,c_end));
    }

    return c_value;

}

function mostraSplashPopup(facebook,company){

    preload = false;
    pagepopup = '/fb-popup/fb-popup.php';

    $('<div id="splash" class="modal" style="display:none;" ></div>').modal({
            show: true
        });
        // console.log(pagepopup);
        if (preload === false){ 
            $.ajax({
                url: pagepopup,
                data: {'facebook':facebook,'company':company},
                success: function(data){
                    $('#splash').html(data);
                }
            });
        }

        setTimeout(function(){$('.ui-dialog .ui-dialog-titlebar-close').show()},3000);


    /*      $.fancybox({'overlayColor'      : '#000',
                'overlayOpacity'            : 0.7,
                'titleShow'         : false,
                'hideOnOverlayClick': false,
                'autoScale'         : false,
                'scrolling'         : 'no',
                'transitionIn'      : 'elastic',
                'transitionOut'     : 'elastic',
                'type'              : 'inline',
                'content'           : $('#splashpopup').html()}
              ); */
    // }
}
