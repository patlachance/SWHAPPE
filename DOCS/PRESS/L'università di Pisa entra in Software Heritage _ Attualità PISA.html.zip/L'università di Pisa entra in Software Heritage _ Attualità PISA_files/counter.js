var _apcounter = _apcounter || [];
(function () {
     var h = (_apcounter['slice']) ? _apcounter.slice(0) : [];
    _apcounter = {
        image: new Image(),
        counter: function (options) {
            var options = options || {};
            var a = this.url(options);
            if (a) {
                this.image.src = a;
                var tempo = 31536000;
                if (!this.getCookie('_ap_counter')) {
                    this.setCookie('_ap_counter', this.randomString(10), tempo)
                } else {
                    this.setCookie('_ap_counter', this.getCookie('_ap_counter'), tempo)
                }
            }
        },
        push: function (a) {
            var b = a.shift();
            if (b == 'counter') {
                _apcounter.counter()
            }
        },
        url: function (options) {
            var options = options || {};
            var forceUrl = options.url || null;
            var metadata = options.metadata || {};
            var forceTitle = options.title || null;
            var a, b, c, d = document.getElementById('aperion-counter-id');
            if (d) {
                b = d.getAttribute('data-site-id');
                c = d.getAttribute('data-metadata');
                a = d.src.replace('/counter.js', '/counter.php');
                a += "?company=" + b;
                a += "&resource=" + ((forceUrl)?this.escape(this.normalizeUrl(forceUrl)):this.resource());
                a += "&title=" + ((forceTitle)?this.escape(forceTitle):this.title());
                a += "&uniqueid=" + this.unique();
                a += "&timestamp=" + this.timestamp();
                if (c) {
                    var m = JSON.parse(c);
                    for (var attrname in metadata) {
                        m[attrname] = metadata[attrname];
                    }
                    a += "&metadata=" + this.escape(JSON.stringify(m));
                }
            }
            return a
        },
        domain: function () {
            return window.location.hostname
        },
        escape: function (a) {
            return (typeof (encodeURIComponent) == 'function') ? encodeURIComponent(a) : escape(a)
        },
        normalizeUrl: function(url) {
            return (url.split('?')[0].split('#')[0].toLowerCase().replace(/^(https?):\/\/m\./,"$1://www."));
        },
        resource: function () {
            var canonical = "";
            var links = document.getElementsByTagName("link");
            for (var i = 0; i < links.length; i ++) {
                if (links[i].getAttribute("rel") === "canonical") {
                    canonical = links[i].getAttribute("href")
                }
            }
            if (canonical) {
                return this.escape(canonical);
            } else {
                var url = this.normalizeUrl(document.location.href);
                return this.escape(url);
            }
        },
        timestamp: function () {
            return new Date().getTime()
        },
        title: function () {
            return (document.title && document.title != "") ? this.escape(document.title) : ''
        },
        unique: function () {
            return this.getCookie('_ap_counter')
        },
        setCookie: function (a, b, d) {
            var f, c;
            b = escape(b);
            if (d) {
                f = new Date();
                f.setTime(f.getTime() + (d * 1000));
                c = '; expires=' + f.toGMTString()
            } else {
                c = ''
            }
            document.cookie = a + "=" + b + c + "; path=/"
        },
        getCookie: function (a) {
            var b = a + "=",
                d = document.cookie.split(';');
            for (var f = 0; f < d.length; f++) {
                var c = d[f];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1, c.length)
                }
                if (c.indexOf(b) == 0) {
                    return unescape(c.substring(b.length, c.length))
                }
            }
            return null
        },
        randomString: function (length) {
            var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
            if (! length) {
                length = Math.floor(Math.random() * chars.length);
            }
            var str = '';
            for (var i = 0; i < length; i++) {
                str += chars[Math.floor(Math.random() * chars.length)];
            }
            return str;
        }
    };
    _apcounter.counter();
    for (var g = 0, j = h.length; g < j; g++) {
        _apcounter.push(h[g]);
    }
})();
