/*
 Copyright 2014 Google Inc. All rights reserved.

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

(function(window) {

  if (!!window.cookieChoices) {
    return window.cookieChoices;
  }

  var document = window.document;
  // IE8 does not support textContent, so we should fallback to innerText.
  var supportsTextContent = 'textContent' in document.body;

  var cookieChoices = (function() {

    var cookieName = 'displayCookieConsent';
    var cookieConsentId = 'cookieChoiceInfo';
    // Edit: id div per lightbox
    var cookieConsentIdDialog = 'cookies-dialog';
    var dismissLinkId = 'cookieChoiceDismiss';
    var dismissLinkText = 'Chiudi';

    // Edit: aggiunto parametro style; Posizionamento in basso
    function _createHeaderElement(cookieText, dismissText, linkText, linkHref, style, lingua) {
      var butterBarStyles = 'position:fixed;width:100%;' +
          'margin:0; left:0; bottom:0;padding:4px;z-index:999999999;text-align:center;';

      // Edit: stili di base (posizionamento) + stili via parametro
      butterBarStyles += style;

      // Edit: prendo la lingua del navigatore
      var linguaNav = navigator.language || navigator.userLanguage;
      linguaNav = linguaNav.substr(0, 2);

      // Edit: Valuto se la lingua del navigatore è diversa da quella impostata da noi o di default
      // se diversa, prendo come lingua effettiva la lingua del navigatore
      var lingua_f = '';
      if(linguaNav != lingua)
        lingua_f = linguaNav;
      else
        lingua_f = lingua;

      // Edit: Prendo il testo della barra dal file, definendo la lingua
      // JSON: 0 => Testo, 1 => Click per popup, 2 => dismiss
      // ATTENZIONE: per modificare la scritta, definire qui l'array delle lingue come variabile globale
      loadHTML('https://www.aperion.it/quinews_cookies.php?lan='+lingua_f+'&text=1', butterBarStyles, linkText, linkHref, lingua);

    }

    function _createDialogElement(cookieText, dismissText, linkText, linkHref, lingua) {
      var glassStyle = 'position:fixed;width:100%;height:100%;z-index:999;' +
          'top:0;left:0;opacity:0.5;filter:alpha(opacity=50);' +
          'background-color:#ccc;';
      var dialogStyle = 'z-index:1000;position:fixed;left:50%;top:50%';
      var contentStyle = 'position:relative;left:-50%;margin-top:-45%;' +
          'background-color:#fff;padding:20px;box-shadow:4px 4px 25px #888;';


      var cookieConsentElement = document.createElement('div');
      cookieConsentElement.id = cookieConsentIdDialog;
      cookieConsentElement.style.display = "none";

      // Edit: Se siamo in mobile cambiamo lo stile
      if (screen && window.innerWidth > 640 ) {
        contentStyle += 'min-width: 590px;';
      }else{
        contentStyle += 'width: 275px;';
        // cookieConsentElement.style.position = 'absolute';
      }

      var glassPanel = document.createElement('div');
      glassPanel.style.cssText = glassStyle;

      var content = document.createElement('div');
      content.style.cssText = contentStyle;

      var dialog = document.createElement('div');
      // dialog.id = 'dialog';
      dialog.style.cssText = dialogStyle;

      // Edit: appendo al contenunto della lightbox l'iframe
      // Edit: aggiunto controllo lingua (preso da parametro);
      var linguaNav = navigator.language || navigator.userLanguage;
      linguaNav = linguaNav.substr(0, 2);
      
      if(lingua != linguaNav)
        lingua = linguaNav;

      var dismissLink = _createDismissLink(dismissLinkText);
      dismissLink.style.display = 'block';
      dismissLink.style.textAlign = 'right';
      dismissLink.style.marginTop = '8px';

      content.appendChild(_createConsentText(cookieText));
      
      // Edit: file unico multilingua
      content.appendChild(_createIframe('https://www.aperion.it/quinews_cookies.php?domain='+window.location.hostname+'&lan='+lingua));
      
      if (!!linkText && !!linkHref) {
        content.appendChild(_createInformationLink(linkText, linkHref, lingua));
      }
      content.appendChild(dismissLink);
      dialog.appendChild(content);
      cookieConsentElement.appendChild(glassPanel);
      cookieConsentElement.appendChild(dialog);
      return cookieConsentElement;
    }

    function _setElementText(element, text) {
      if (supportsTextContent) {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    }

    // EDIT: setting iframe
    function _setIframe(element, src) {
      element.setAttribute("src", src);
      element.style.width = 100+"%";
      element.style.border = "none";
      if (screen && window.innerWidth > 640 ) {
        element.style.height = 480+"px";
      }else{
        element.style.height = 300+"px";
      }
    }

    // EDIT: create iframe
    function _createIframe(src) {
      var iframe = document.createElement('iframe');
      _setIframe(iframe, src);
      return iframe;
    }

    function _createConsentText(cookieText) {
      var consentText = document.createElement('span');
      _setElementText(consentText, cookieText);
      return consentText;
    }

    function _createDismissLink(dismissText) {
      var dismissLink = document.createElement('a');
      _setElementText(dismissLink, dismissText);
      dismissLink.className = dismissLinkId;
      dismissLink.href = '#';
      dismissLink.style.marginLeft = '24px';
      return dismissLink;
    }

    function _createInformationLink(linkText, linkHref, lingua) {
      var infoLink = document.createElement('a');
      _setElementText(infoLink, linkText);
      infoLink.href = linkHref;
      // infoLink.target = '_blank';
      // Edit: sul click del primo link apro il lightbox e rimuovo la barra
      infoLink.setAttribute('onclick', "document.getElementById('"+cookieConsentIdDialog+"').style.display = 'block';document.getElementById('"+cookieConsentId+"').parentNode.removeChild(document.getElementById('"+cookieConsentId+"'));return false;_saveUserPreference();");

      infoLink.style.marginLeft = '8px';
      return infoLink;
    }

    function _dismissLinkClick() {
      _saveUserPreference();
      _removeCookieConsent();
      return false;
    }

    // Edit: aggiunto style come parametro (ricordarsi di riguardare tutti i parametri per le funzioni)
    function _showCookieConsent(cookieText, dismissText, linkText, linkHref, style, isDialog, lingua) {
      if (_shouldDisplayConsent()) {
        _removeCookieConsent();
        if(typeof(lingua) === 'undefined')
          lingua = 'en';
        var consentElement = (isDialog) ?
            _createDialogElement(cookieText, dismissText, linkText, linkHref, lingua) :
            _createHeaderElement(cookieText, dismissText, linkText, linkHref, style, lingua);
       
      }
    }

    // Edit: Aggiunto style
    function showCookieConsentBar(cookieText, dismissText, linkText, linkHref, style, lingua) {
      _showCookieConsent(cookieText, dismissText, linkText, linkHref, style, false, lingua);
    }

    // Edit: Aggiunto style
    function showCookieConsentDialog(cookieText, dismissText, linkText, linkHref, lingua) {
      _showCookieConsent(cookieText, dismissText, linkText, linkHref, '', true, lingua);
    }

    function _removeCookieConsent() {
      var cookieChoiceElement = document.getElementById(cookieConsentId);
      if (cookieChoiceElement != null) {
        cookieChoiceElement.parentNode.removeChild(cookieChoiceElement);
      }
      // Edit: se c'è il lightbox, si rimuove alla chiusura
      var cookieDialog = document.getElementById(cookieConsentIdDialog);
      if( cookieDialog != null){
        cookieDialog.parentNode.removeChild(cookieDialog);
      }
    }

    function _saveUserPreference() {
      // Set the cookie expiry to one year after today.
      var expiryDate = new Date();
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
      document.cookie = cookieName + '=y; expires=' + expiryDate.toGMTString();
    }

    function _shouldDisplayConsent() {
      // Display the header only if the cookie has not been set.
      return !document.cookie.match(new RegExp(cookieName + '=([^;]+)'));
    }

    function loadHTML(theURL, styles, linkText, linkHref, lingua) {
      if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari, SeaMonkey
        xmlhttp=new XMLHttpRequest();
      }else{// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      xmlhttp.onreadystatechange=function() {
        if (xmlhttp.readyState==4 && xmlhttp.status==200) {
          // Creo la barra
          var div = document.createElement('div');
          div.id = cookieConsentId;
          div.style.cssText = styles;
          // Recupero i testi
          var text = JSON.parse(xmlhttp.responseText);
          
          // Inserisco i testi nella barra
          div.appendChild(_createConsentText(text[0]));

          if ((!!linkText || !!text[1]) && !!linkHref) {
            div.appendChild(_createInformationLink(text[1], linkHref, lingua));
          }

          dismissLinkText = text[2];
          div.appendChild(_createDismissLink(text[2]));
          // Appendo la barra alla fine del body
          appendElement(div);
          // Creo la finestra della privacy
          var dialog = _createDialogElement('', '', '', '', lingua);
          // Appendo la finestra della privacy
          appendElement(dialog);
        }
      }

      xmlhttp.open("GET", theURL, 1);
      xmlhttp.send();
    }

    // Appendo l'elemento alla fine del body ed assegno l'onclick
    function appendElement(el){
        var fragment = document.createDocumentFragment();
        fragment.appendChild(el);
        document.body.appendChild(fragment.cloneNode(true));

        document.getElementsByClassName(dismissLinkId)[0].onclick = _dismissLinkClick;
        if(typeof(document.getElementsByClassName(dismissLinkId)[1]) !== 'undefined'){
          document.getElementsByClassName(dismissLinkId)[1].onclick = _dismissLinkClick;
        }
    }

    var exports = {};
    exports.showCookieConsentBar = showCookieConsentBar;
    exports.showCookieConsentDialog = showCookieConsentDialog;
    return exports;
  })();

  window.cookieChoices = cookieChoices;
  return cookieChoices;
})(this);